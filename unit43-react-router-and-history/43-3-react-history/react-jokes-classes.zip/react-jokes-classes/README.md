### Initialization

```
npm install && npm start
```
